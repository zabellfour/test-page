name: test page 
description: html css js

To run develop mode do next:
- npm i
- grunt