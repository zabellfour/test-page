// All imports in this file will be compiled into vendors.js file.
//
// Note: ES6 support for these imports is not supported in base build

module.exports = [
  './node_modules/jquery/dist/jquery.js',
  './node_modules/bootstrap-sass/assets/javascripts/bootstrap.min.js',
  './node_modules/jquery-match-height/dist/jquery.matchHeight.js',
  './node_modules/owl.carousel/dist/owl.carousel.js',
  './node_modules/jquery-validation/dist/jquery.validate.js'
];
